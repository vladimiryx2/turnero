namespace Turnero.Models{
    public class Tv{
        public int Id { get; set;}
        public string TurnoId { get; set;}
        public string  puesto { get; set;} 
        public int IdTurno { get; set;}
    }
}