namespace Turnero.Models{
    public class Turno{
        public int Id { get; set;}
        public string Tipo { get; set;}
        public int Numero { get; set;} 
        public int ModuloId { get; set;}

    }
}
