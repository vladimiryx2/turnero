namespace Turnero.Models{
    public class HistorialTurno{
        public int Id { get; set;}
        public string Tipo { get; set;}
        public int Numero { get; set;}
         public string Modulo { get; set;}


    }
}